package com.vibhor;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public 	class EarthQuakeReducer extends Reducer<Text, Text, Text, Text> {
	@Override
	public void reduce(Text key, Iterable<Text> values, Context context)
			throws IOException, InterruptedException {

		double maxmagnitude = Double.MIN_VALUE;
		String year  = " ";
		String latitude  = " ";
		String longitude = " ";
		String depth = " ";
		double magnitude = 0.0;
		String monthString=" ";
		
		for(Text val: values){
		
			String [] valTokens = val.toString().split(",");
			magnitude = Double.parseDouble(valTokens[9]);
		
			    if(magnitude > maxmagnitude){
			    year=valTokens[0];
			    latitude = valTokens[6];
			    longitude = valTokens[7];
			    depth = valTokens[8];
			    maxmagnitude = magnitude;
			    monthString = key.toString();
			} 
		} 
		context.write(new Text("Year- "+year+"\t"+"\tMonth- "+monthString+"\t"+"Latitude- "+latitude), new Text("\tLongitude- "+longitude+"\tDepth- "+depth+"\tMagnitude- "+maxmagnitude));
	}
} 

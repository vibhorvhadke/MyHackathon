package com.vibhor;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

	public class EarthQuakeYearPartition extends Partitioner<Text, Text> {

		@Override
		public int getPartition(Text key, Text value, int numReduceTasks) {

			String [] remainingEarthQuakeData = value.toString().split(",");
			String month = remainingEarthQuakeData[1];
			int monthInt = Integer.parseInt(month);
			
			
			if(numReduceTasks == 0)
				return 0;

			
			if(monthInt >0 && monthInt <=3){				
				return 0;
			}
			
			if(monthInt >3 && monthInt <=6){
				
				return 1 % numReduceTasks;
			}
			
			if(monthInt >6 && monthInt <=9){
				
				return 2 % numReduceTasks;
			}
			else
				return 3 % numReduceTasks;
		} 
	} 

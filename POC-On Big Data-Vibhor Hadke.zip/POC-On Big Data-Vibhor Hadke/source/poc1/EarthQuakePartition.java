package com.vibhor;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
public class EarthQuakePartition{

	public static void main(String[] args) {
		try{
		Configuration conf = new Configuration();
	    
	    Job job = new Job(conf, "Earth Quake Partitioning ");
	    
	    job.setJarByClass( EarthQuakePartition.class );
	    job.setMapperClass( EarthQuakeMapper.class );
	    job.setReducerClass( EarthQuakeReducer.class );
	    job.setPartitionerClass(EarthQuakeYearPartition.class);
	    job.setNumReduceTasks(4);
	    
	    job.setMapOutputKeyClass( Text.class );
	    job.setMapOutputValueClass( Text.class );
	    
	    job.setOutputKeyClass( Text.class );	    
	    job.setOutputValueClass( Text.class );
	    
	    FileInputFormat.addInputPath( job, new Path( args[0] ) );
	    FileOutputFormat.setOutputPath( job, new Path( args[1] ) );
	    
	    System.exit( job.waitForCompletion( true ) ? 0 : 1 );
		}//end of try
		catch(Exception e){e.printStackTrace();}
		}//end of main
	}//end of class
